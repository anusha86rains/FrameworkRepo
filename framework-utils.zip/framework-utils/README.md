# framework-utils

This project is custom test-framework and provides utilities to make rest services requests, initialize configurations, create data provider objects, browser and page objects features, reporting and logging capabilities using Selenium webdriver 2.0, Java, TestNG, Rest Assured. A jar is created of this project and uploaded in nexus repository. It can be imported as maven or gradle dependency into the test projects.

```
How to import framework-utils library as a dependency in a gradle project.
	Add below line to the dependencies task in gradle build file.
	  `compile group: 'com.esri', name: 'framework-utils', version: testFrameworkVersion`
	  - testFrameworkVersion is a variable and value is set in the gradle.properties. The current version is 2.0.0
```
```
Features:
	- TestNg DataProvider uses an CSV file to initialize the input parameters to the test case.
	- Logging - Custom logger is implemented that can be called static manner to log e.g Log.info("message", optional throwable).
	- HTML Reports after test execution are created using extent libraries. it reports all the soft assertions and also the stack trace if there are failures.
	- Properties can be read by passing property file name to the PropertiesReader object.
	- The reports are created by adding testng listeners in the testng-xml file. Reporting Dashboard is also provided which stores the historic results identified by the test project name and the   release. It pulls the data from mongoDb which is installed as part of installing extentX application.
```
```
Steps to import the project into IDE for further development.
	1) Create a local directory and run `git init` in that directory.
	2) Create clone of the git repository in same directory.
	3) Import the gradle prject in the IDE of your choice.
	4) After making the changes, please upload the new release version into the nexus using gradle upload task and also change the version of framework in the test projects dependent upon test-framework.
		Upload SNAPSHOT version: ./gradlew clean build upload (make sure that gradle.properties has the correct SNAPSHOT version. Eg. 2.0-SNAPSHOT)
		Upload Release Version: ./gradlew clean build upload -Pversion=2.0.0 -PnexusUploadLocation=http://ist000532:8081/repository/maven-releases
```
```
Environment needs:
	Need GIT, Gradle 3.4 and java 8 configured on the system.  
```
