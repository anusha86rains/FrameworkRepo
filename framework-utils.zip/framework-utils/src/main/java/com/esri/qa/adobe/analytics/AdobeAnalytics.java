package com.esri.qa.adobe.analytics;

import org.openqa.selenium.WebDriver;

import com.esri.qa.config.PropertiesReader;

/**
 * This Class provides the utilities to validate adobe anlytics scripts are available on the page source
 * 
 * @author Deenesh
 */
public class AdobeAnalytics {

	private String filename = "expected-scripts.properties";
	private WebDriver driver;
	private PropertiesReader reader;
	
	public AdobeAnalytics(WebDriver driver) {
		this.driver = driver;
		this.reader = new PropertiesReader(filename);
	}

	/**
	 * check if google tag script is available
	 * 
	 * @return boolean
	 */
	public boolean isGoogleTagScriptExists() {
		boolean isExists = false;
		if (driver.getPageSource().contains(reader.getConfigProperty("GoogleTagManagerScript"))) {
			isExists = true;
		}
		return isExists;
	}

	/**
	 * check if google tag no script is available
	 * 
	 * @return boolean
	 */
	public boolean isGoogleTagNoScriptExists() {
		boolean isExists = false;
		if (driver.getPageSource().contains(reader.getConfigProperty("GoogleTagManagerNoScript"))) {
			isExists = true;
		}
		return isExists;
	}
	
	/**
	 * check if Adobe analytics header script is available
	 * 
	 * @return boolean
	 */
	public boolean isHeaderScriptExists() {
		boolean isExists = false;
		if (reader==null) {
			reader = new PropertiesReader(filename);
		}
		if (driver.getPageSource().contains(reader.getConfigProperty("HeaderEmbedCode"))) {
			isExists = true;
		}
		return isExists;
	}
	
	/**
	 * check if pardot script is available
	 * 
	 * @return boolean
	 */
	public boolean isPardotScriptExists() {
		boolean isExists = false;
		if (driver.getPageSource().contains(reader.getConfigProperty("PardotLayerCode"))) {
			isExists = true;
		}
		return isExists;
	}
	
	/**
	 * check if footer script is available
	 * 
	 * @return boolean
	 */
	public boolean isFooterScriptExists() {
		boolean isExists = false;
		if (driver.getPageSource().contains(reader.getConfigProperty("FooterEmbedCode"))) {
			isExists = true;
		}
		return isExists;
	}

}
