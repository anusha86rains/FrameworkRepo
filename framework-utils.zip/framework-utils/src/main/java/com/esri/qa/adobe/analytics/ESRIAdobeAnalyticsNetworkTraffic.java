package com.esri.qa.adobe.analytics;

import java.io.FileOutputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Proxy;

import com.esri.qa.reporting.Log;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.proxy.CaptureType;

public class ESRIAdobeAnalyticsNetworkTraffic {

	private BrowserMobProxy server;
	private Proxy proxy;
	private Har har;

	public ESRIAdobeAnalyticsNetworkTraffic() {
		server = new BrowserMobProxyServer();
	}

	public void setHTTPProxy() {
		if (server == null) {
			server = new BrowserMobProxyServer();
		}
		
		server.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
				CaptureType.REQUEST_BINARY_CONTENT);
		server.start(0);
		proxy = ClientUtil.createSeleniumProxy(server);
		server.newHar("esri.com");
	}

	public Proxy getHTTPPRoxy() throws UnknownHostException {
		if (proxy == null) {
			setHTTPProxy();
		}
		proxy.setHttpProxy("ist000582.esri.com"+ ":" + server.getPort());
//		Log.info("info:" + server.getPort());
//		proxy.setSslProxy("localhost:"+ server.getPort());
		return proxy;
	}

	public void createHarFile() {
		har = server.getHar();
		Log.info("Har Entries: " + har.getLog().getEntries().size());
		try (FileOutputStream fos = new FileOutputStream("./ESRI-HAR-Information.har");) {
			har.writeTo(fos);
		} catch (Exception e) {
			Log.error("Unable to create HAR file", e);
		} 
	}
	
	 public void stopServer () {
		 server.stop();
	 }
		 
	public Har getHarFile() {
		return har;
	}

	public List<HarEntry> retrieveHarEntries() {
		if (har == null) {
			createHarFile();
		}
		har.getLog().getPages();
		return har.getLog().getEntries();
	}

	public List<HarDataBean> retrieveNetworkRequests() {
		List<HarDataBean> requests = new ArrayList<>();
		if (har == null) {
			createHarFile();
		}

		for (HarEntry hardata : har.getLog().getEntries()) {
			if (hardata.getRequest().getUrl().contains("pardot") || hardata.getRequest().getUrl().contains("0ed1001fd441a838aefe8e755be42aaafddcc46b")
					|| hardata.getRequest().getUrl().contains("go.esri")) {
				HarDataBean trafficData = new HarDataBean();
				int index = hardata.getRequest().getUrl().indexOf('?');
				if (index > 1) {
					trafficData.setEndPoint(hardata.getRequest().getUrl().substring(0, index));
				} else {
					trafficData.setEndPoint(hardata.getRequest().getUrl());
				}
				trafficData.setUrl(hardata.getRequest().getUrl());
				trafficData.setResponseTime(hardata.getTime(TimeUnit.SECONDS));
				trafficData.setStatus(hardata.getResponse().getStatus());
				requests.add(trafficData);
			}
		}
		return requests;
	}

	public List<HarDataBean> retrieveFailedNetworkRequests() {
		List<HarDataBean> requests = new ArrayList<>();
		if (har == null) {
			createHarFile();
		}

		for (HarEntry hardata : har.getLog().getEntries()) {
			HarDataBean trafficData = new HarDataBean();

			// the end-points urls may be too long with all the parameters, so
			// truncating it before saving in object
			int index = hardata.getRequest().getUrl().indexOf('?');
			if (index > 1) {
				trafficData.setEndPoint(hardata.getRequest().getUrl().substring(0, index));
			} else {
				trafficData.setEndPoint(hardata.getRequest().getUrl());
			}
			trafficData.setUrl(hardata.getRequest().getUrl());
			trafficData.setResponseTime(hardata.getTime(TimeUnit.SECONDS));
			trafficData.setStatus(hardata.getResponse().getStatus());
			requests.add(trafficData);
		}
		return requests;
	}

}