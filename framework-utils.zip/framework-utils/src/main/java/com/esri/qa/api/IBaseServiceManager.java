package com.esri.qa.api;

import com.esri.qa.api.RestAssuredUtil.HTTP_METHOD;

import io.restassured.response.Response;

/**
 * This interface class is to define some of the default behavior for the
 * service manager classes
 * 
 * 
 * @author deeneshgupta
 *
 */

public interface IBaseServiceManager {

	/**
	 * Method to retrieve the response Object
	 * 
	 */
	Response getResponse();

	/**
	 * Method to retrieve the response status
	 * 
	 */
	int getResponseStatus();

	/**
	 * Method to retrieve the response status
	 * 
	 */
	Object getResponseMessage();

	/**
	 * Method to initialize the request
	 * 
	 */
	void initializeRequest();

	/**
	 * Method to set header
	 * 
	 */
	void setHeader();

	/**
	 * Method to set query params
	 * 
	 */
	void setQueryParameters();

	/**
	 * Method to set query params
	 * 
	 */
	void setFormParameters();

	/**
	 * Method to set cookies
	 * 
	 */
	void setCookie();

	/**
	 * Method to send request and generate response
	 * 
	 */
	void sendRequest(HTTP_METHOD method);

}
