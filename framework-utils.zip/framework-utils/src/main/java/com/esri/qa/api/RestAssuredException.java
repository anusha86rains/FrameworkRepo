package com.esri.qa.api;

/**
 * Custom Exception Class to throw exceptions in the TestNG utilities modules.
 * 
 * @author deenesh
 *
 */
@SuppressWarnings("serial")
public class RestAssuredException extends RuntimeException {

    public RestAssuredException() {
        // no op default constructor
    }

    /**
     * Constructor thats accepts string message.
     * 
     * @param message
     */
    public RestAssuredException(String message) {
        super(message);
    }

    /**
     * Constructor thats accepts throwable exception
     * 
     * @param exception
     *            to be thrown.
     */
    public RestAssuredException(Throwable e) {
        super(e);
    }

    /**
     * Constructor thats accepts throwable exception
     * 
     * @param message
     *            to be shown on the report
     * @param exception
     *            message to be thrown
     */
    public RestAssuredException(String message, Throwable e) {
        super(message, e);
    }
}
