package com.esri.qa.api;

import static io.restassured.RestAssured.given;
import static io.restassured.filter.log.LogDetail.BODY;
import static io.restassured.filter.log.LogDetail.PARAMS;

import java.io.PrintStream;
import java.io.StringWriter;
import java.util.Map;

import org.apache.commons.io.output.WriterOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.testng.SkipException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.esri.qa.config.Config;
import com.esri.qa.config.Config.ConfigProperty;
import com.esri.qa.core.CollectionUtils;
import com.esri.qa.reporting.Log;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;;

/**
 * This class provides methods to interact with Rest Services using rest
 * assured.
 * 
 * @author deenesh
 */
public class RestAssuredUtil {

	private static final String ERROR_GET_RESPONSE = "Unable to get API Response for endpoint ";
	private static final String ERROR_CREATE_REQUEST = "Unable to create API request ";
	private static final int SOCKET_TIMEOUT = Integer.parseInt(Config.getConfigProperty(ConfigProperty.API_SOCKET_TO));
	private static final int CONNECTION_TIMEOUT = Integer
			.parseInt(Config.getConfigProperty(ConfigProperty.API_CONNECTION_TO));

	public enum HTTP_METHOD {
		GET, POST, PUT, DELETE, INV_VAL
	}

	protected RestAssuredUtil() {
		// no op
	}

	/**
	 * @param apiEndPoint
	 * @param queryParamsMap
	 * @param headersMap
	 * @return
	 */
	public static RequestSpecification createRequestSpecification(String endPointUrl, Map<String, ?> pathParamsMap,
			Map<String, ?> queryParamsMap, Map<String, ?> formParamsMap, Map<String, String> headersMap,
			Map<String, ?> cookies, Object requestBody) {
		RequestSpecBuilder requestBuilder = new RequestSpecBuilder();
		try {
			if (CollectionUtils.isNotEmpty(queryParamsMap, "requestQueryParameters")) {
				requestBuilder.addQueryParams(queryParamsMap);
			}
			if (CollectionUtils.isNotEmpty(pathParamsMap, "pathParamsMap")) {
				requestBuilder.addPathParams(pathParamsMap);
			}
			if (CollectionUtils.isNotEmpty(formParamsMap, "requestFormParameters")) {
				requestBuilder.addFormParams(formParamsMap);
			}
			if (CollectionUtils.isNotEmpty(headersMap, "requestHeader")) {
				requestBuilder.addHeaders(headersMap);
			}
			if (CollectionUtils.isNotEmpty(cookies, "requestcookies")) {
				requestBuilder.addCookies(cookies);
			}
			if (requestBody != null) {
				requestBuilder.setBody(requestBody);
			}
		} catch (Exception e) {
			Log.error(ERROR_CREATE_REQUEST + endPointUrl, e);
			throw new RestAssuredException(ERROR_CREATE_REQUEST + endPointUrl, e);
		}
		HttpClientConfig httpClientConfig = new HttpClientConfig()
				.setParam("http.connection.timeout", CONNECTION_TIMEOUT)
				.setParam("http.socket.timeout", SOCKET_TIMEOUT);
		requestBuilder.log(LogDetail.PARAMS);
		requestBuilder.setConfig(RestAssured.config().httpClient(httpClientConfig));
		return requestBuilder.build();
	}

	public static RequestSpecification createRequestSpecifications(String endPointUrl) {
		RequestSpecBuilder requestBuilder = new RequestSpecBuilder();
		HttpClientConfig httpClientConfig = new HttpClientConfig()
				.setParam("http.connection.timeout", CONNECTION_TIMEOUT)
				.setParam("http.socket.timeout", SOCKET_TIMEOUT);
		requestBuilder.log(LogDetail.PARAMS);
		requestBuilder.setConfig(RestAssured.config().httpClient(httpClientConfig));
		return requestBuilder.build();
	}

	/**
	 * 
	 * This method calls REST API with given endpoint No need to send
	 * apiEndpoint if the base path is already set to absolute api endpoint path
	 * 
	 * @param method
	 * @param apiEndPoint
	 * @param queryParamsMap
	 * @param headersMap
	 * @param requestBody
	 * @return
	 */
	public static Response sendServiceRequest(HTTP_METHOD method, String apiEndPoint, Map<String, ?> pathParamsMap,
			Map<String, ?> queryParamsMap, Map<String, ?> formParamsMap, Map<String, String> headersMap,
			Map<String, ?> cookies, Object requestBody, ExtentTest test) {
		Response response;
		String endPointUrl = RestAssured.basePath;
		RequestSpecification requestSpecification = createRequestSpecification(endPointUrl, pathParamsMap,
				queryParamsMap, formParamsMap, headersMap, cookies, requestBody);

		StringWriter writer = new StringWriter();
		PrintStream outputStream = new PrintStream(new WriterOutputStream(writer, "UTF-8"), true);
		requestSpecification.filter(logRequestParamsToFile(outputStream));

		if (requestBody != null) {
			requestSpecification.filter(logRequestRequestBodyToFile(outputStream));
		}

		try {
			if (StringUtils.isBlank(apiEndPoint)) {
				response = callWebservice(method, requestSpecification, writer, test);
			} else {
				endPointUrl = endPointUrl + apiEndPoint;
				response = callWebservice(method, requestSpecification, apiEndPoint, writer, test);
			}
		} catch (Exception e) {
			Log.error(ERROR_GET_RESPONSE + endPointUrl, e);
			throw new SkipException(ERROR_GET_RESPONSE + endPointUrl, e);
		}
		return response;
	}

	public static RequestLoggingFilter logRequestParamsToFile(PrintStream stream) {
		return new RequestLoggingFilter(PARAMS, stream);
	}

	public static RequestLoggingFilter logRequestRequestBodyToFile(PrintStream stream) {
		return new RequestLoggingFilter(BODY, stream);
	}

	public static Response callWebservices(HTTP_METHOD method, RequestSpecification requestSpecification,
			StringWriter writer) {
		Response response = null;
		switch (method) {
		case GET:
			response = given().spec(requestSpecification).when().get();
			break;
		case POST:
			response = given().spec(requestSpecification).when().post();
			break;
		case PUT:
			response = given().spec(requestSpecification).when().put();
			break;
		case DELETE:
			response = given().spec(requestSpecification).when().delete();
			break;
		default:
			break;
		}
		if (response != null) {
			Log.debug("Response Output " + response.asString());
		}
		/*
		 * if (test != null) { test.log(Status.INFO, "Request Content: " +
		 * writer.toString()); }
		 */
		return response;
	}

	public static Response callWebservice(HTTP_METHOD method, RequestSpecification requestSpecification,
			StringWriter writer, ExtentTest test) {
		Response response = null;
		switch (method) {
		case GET:
			response = given().spec(requestSpecification).when().get();
			break;
		case POST:
			response = given().spec(requestSpecification).when().post();
			break;
		case PUT:
			response = given().spec(requestSpecification).when().put();
			break;
		case DELETE:
			response = given().spec(requestSpecification).when().delete();
			break;
		default:
			break;
		}
		if (response != null) {
			Log.debug("Response Output " + response.asString());
		}
		if (test != null) {
			test.log(Status.INFO, "Request Content: " + writer.toString());
		}
		return response;
	}

	public static Response callWebservice(HTTP_METHOD method, RequestSpecification requestSpecification,
			String apiEndPoint, StringWriter writer, ExtentTest test) {
		Response response = null;
		// int port1 = 8081;
		switch (method) {
		case GET:
			response = given().when().get(apiEndPoint).then().contentType(ContentType.JSON).extract().response();
			break;
		case POST:
			response = given().spec(requestSpecification).when().post(apiEndPoint);
			break;
		case PUT:
			response = given().spec(requestSpecification).when().put(apiEndPoint);
			break;
		case DELETE:
			response = given().spec(requestSpecification).when().delete(apiEndPoint);
			break;
		default:
			break;
		}
		if (response != null) {
			Log.debug("Response Output " + response.asString());
		}
		if (test != null) {
			test.log(Status.INFO, "Request Content: " + writer.toString());
		}
		return response;
	}

	/**
	 * This method calls REST API with given endpoint without any headers.
	 * 
	 * @param apiEndPoint
	 * @param objectType
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getResponse(String apiEndPoint, Class<T> objectType, RequestSpecification request) {
		T response = null;
		try {
			Log.info("Creating client response for endPoint: " + apiEndPoint);
			response = (T) given().spec(request).when().get(apiEndPoint).as(objectType.getClass());
		} catch (Exception e) {
			Log.error(ERROR_GET_RESPONSE + apiEndPoint, e);
			throw new RestAssuredException(ERROR_GET_RESPONSE + apiEndPoint, e);
		}
		return response;
	}

}
