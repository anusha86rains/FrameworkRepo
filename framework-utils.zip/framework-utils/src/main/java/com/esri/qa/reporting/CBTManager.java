package com.esri.qa.reporting;

import java.util.HashMap;
import java.util.Map;

import org.testng.ITestContext;

import com.esri.qa.api.RestAssuredUtil;
import com.esri.qa.api.RestAssuredUtil.HTTP_METHOD;
import com.esri.qa.config.Config;
import com.esri.qa.config.Config.ConfigProperty;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;

public class CBTManager {

	private static final String SETSCORE_ENDPOINT = "selenium/{seleniumTestId}";

	public CBTManager() {
		// no-op
	}

	public static void setScore(String sessionId, ITestContext context) {
		try {
			String testScore = setStatus(context);
			String username = Config.getConfigProperty(ConfigProperty.CBT_USER);
			String authkey = Config.getConfigProperty(ConfigProperty.CBT_KEY);
			RestAssured.baseURI = Config.getConfigProperty(ConfigProperty.CBT_URL);
			RestAssured.authentication = RestAssured.basic(username, authkey);
			RestAssured.defaultParser = Parser.JSON;
			Map<String, ?> dummyMap = new HashMap<>();
			Map<String, String> headerMap = new HashMap<>();
			Map<String, String> formParamsMap = new HashMap<>();
			Map<String, String> pathParams = new HashMap<>();
			formParamsMap.put("action", "set_score");
			formParamsMap.put("score", testScore);
			pathParams.put("seleniumTestId", sessionId);
			RestAssuredUtil.sendServiceRequest(HTTP_METHOD.PUT, SETSCORE_ENDPOINT, pathParams, dummyMap, formParamsMap, headerMap, dummyMap, null, null);
		} catch (Exception e) {
			Log.error("Unable to set test status in CBT", e);
		}
	}

	public static String setStatus(ITestContext context) {
		String status = null;
		int totalTests = context.getAllTestMethods().length;
		int passedTests = context.getPassedTests().size();
		int failedTests = context.getFailedTests().size();
		int skippedTests = context.getSkippedTests().size();
		Log.info(totalTests + " " +passedTests +" " + failedTests + " " + skippedTests );
		if (totalTests == passedTests) {
			status = "pass";
		} else if (totalTests == failedTests) {
			status = "fail";
		} else if (totalTests == skippedTests) {
			status = "skip";
		} else if (totalTests == (failedTests + passedTests + skippedTests)) {
			status = "partial";
		}
		return status;
	}

}