package com.esri.qa.reporting;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

import java.io.IOException;

/**
 * Set of utility methods to report status to TargetProcess
 *
 * @author Al
 */
public class TargetprocessReporter {

    private static String ps_Token = "MTEwMDpTS0hvcnVPNW93Y0MwZXBTUGVHMDJveW1FaCtRdHdGbEVlYThWZ1hQY2R3PQ==";

    /**
     * Update test case run status in target process
     *
     * @param TestCaseRunID
     * @param Status
     * @param Message
     */
    public static void updateTestCaseRun(int TestCaseRunID, TPRunStatus Status, String Message) {

        //Update information
        String requestParams = String.format("{\"Status\": \"%s\", \"Comment\": \"%s\"}",Status.toString(),Message);
        Log.debug(String.format("Requestparameters - %s", requestParams));

        //Url to post to Targetprocess
        String url = String.format("https://esri.tpondemand.com/api/v1/TestCaseRuns/%s?resultFormat=json&resultInclude=[Id,Name]&access_token=%s",TestCaseRunID,ps_Token);
        Log.debug(String.format("URL - %s", url));

        //Post to Targetprocess and log response
        Response responseTP = given().contentType("application/json").and().body(requestParams).post(url);
        Log.info(String.format("Response - %s", responseTP.asString()));
    }

    public enum TPRunStatus {
        PASSED,
        ONHOLD,
        BLOCKED,
        FAILED;

        @Override
        public String toString() {
            String str = "";
            switch (this) {
                case PASSED:
                    str = "Passed";
                    break;
                case ONHOLD:
                    str =  "On Hold";
                    break;
                case BLOCKED:
                    str =  "Blocked";
                    break;
                case FAILED:
                    str =  "Failed";
                    break;
            }
            return str;
        }
    }

}
