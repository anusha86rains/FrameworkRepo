package com.esri.qa.ui;

import com.applitools.eyes.MatchLevel;
import com.applitools.eyes.RectangleSize;
import org.openqa.selenium.WebDriver;

public class AppliCompareData {

    public String StepName;
    public String TestName;
    public WebDriver Driver;
    public Boolean FullScreenShot;
    public RectangleSize ViewPort;
    public MatchLevel Compare;

    public AppliCompareData(WebDriver Driver, String TestName, String StepName, MatchLevel Match, Boolean FullScreenShot, RectangleSize RectSize ){

        this.ViewPort = RectSize;
        this.Compare = Match;
        this.Driver = Driver;
        this.FullScreenShot = FullScreenShot;
        this.TestName = TestName;
        this.StepName = StepName;
    }

}
