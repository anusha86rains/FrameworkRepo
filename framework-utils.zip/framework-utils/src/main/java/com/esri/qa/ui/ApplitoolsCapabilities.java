package com.esri.qa.ui;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.TestResults;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;
import com.esri.qa.config.Config;
import com.esri.qa.reporting.Log;

public class ApplitoolsCapabilities {

    private Eyes p_Eyes;
    private BatchInfo p_BatchInfo;
    private Boolean p_AppliEnabled = false;
    private Boolean p_EyesClosed = false;

    public ApplitoolsCapabilities(String BatchName, String BatchID){

        if(BatchID.trim().toLowerCase().length() > 1)
        {
            p_BatchInfo = new BatchInfo(BatchName);
            p_BatchInfo.setId( BatchID );
            p_AppliEnabled = true;
        }
    }

    private void initializeEyes(AppliCompareData AData) {

        // Initialize the eyes SDK and set your private API key.
        p_Eyes = new Eyes();
        p_Eyes.setApiKey("SeHi101102VZBGOT1HiwBcr7FEx1Ykg1OMuThhVrWuZFWmI110");
        p_Eyes.setBatch(p_BatchInfo);
        p_Eyes.setStitchMode(StitchMode.CSS);
        p_Eyes.setHideScrollbars(false);
        try {
            // Start the test and set the browser's viewport size to 1080x800.
            p_Eyes.open(AData.Driver, Config.getConfigProperty(Config.ConfigProperty.TEST_APP_NAME), AData.TestName,AData.ViewPort);
        } catch (Exception e) {
            Log.error("Unable to initialize eyes", e);
        }

        return;
    }

    public void appliCompareImage(AppliCompareData AData) {

        if(!p_AppliEnabled)
        {
            Log.info("Applitools not enabled, provide a valid batch id");
            return;
        }

        //initialize eyes object
        if (p_Eyes == null || !p_Eyes.getIsOpen()) {
            initializeEyes(AData);
        }

        //Set Full Page Screenshot
        p_Eyes.setForceFullPageScreenshot(AData.FullScreenShot);

        //Set Comparison Level
        p_Eyes.setMatchLevel(AData.Compare);


        // Visual checkpoint
        p_Eyes.checkWindow(AData.StepName);
    }

    public TestResults getTestResults() {

        if(!p_AppliEnabled || p_Eyes == null)
        {
            Log.info("Applitools not enabled, provide a valid batch id or do an actual image comparision");
            return null;
        }

        TestResults results = p_Eyes.close(false);
        p_Eyes.abortIfNotClosed();
        p_EyesClosed = true;
        return results;
    }

    public void closeAppliTools()
    {
        if(!p_AppliEnabled)
        {
            Log.info("Applitools not enabled, provide a valid batch id");
            return;
        }

        if(!p_EyesClosed)
        {
            TestResults results = p_Eyes.close(false);
            p_Eyes.abortIfNotClosed();
            p_EyesClosed = true;
            Log.info("Test results:" + results) ;
        }
    }
}
