package com.esri.qa.ui;

import com.applitools.eyes.MatchLevel;

public class ComparisonLevel {

    public static MatchLevel STRICT = MatchLevel.STRICT;
    public static MatchLevel NONE = MatchLevel.NONE;
    public static MatchLevel CONTENT = MatchLevel.CONTENT;
    public static MatchLevel LAYOUT = MatchLevel.LAYOUT;
    public static MatchLevel LAYOUT2 = MatchLevel.LAYOUT2;
    public static MatchLevel EXACT = MatchLevel.EXACT;
}