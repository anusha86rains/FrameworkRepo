package com.esri.qa.ui;

import com.applitools.eyes.RectangleSize;

public class ViewPortSize {

    public static RectangleSize MAX = new RectangleSize(1080, 800);
    public static RectangleSize IPHONE7 = new RectangleSize(375, 667);
    public static RectangleSize IPHONE7PLUS = new RectangleSize(414, 736);
    public static RectangleSize SAMSUNG = new RectangleSize(480, 853);
    public static RectangleSize NEXUS = new RectangleSize(411, 731);
    public static RectangleSize TABLET = new RectangleSize(768, 1024);
    public static RectangleSize DESKTOP = new RectangleSize(768, 1024);

}
